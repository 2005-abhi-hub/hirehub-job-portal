/**
 * Custom API error with HTTP status code.
 * Thrown from controllers; caught by the global error handler in server.js.
 *
 * Usage:
 *   throw new ApiError(404, 'Job not found');
 */
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = ApiError;
