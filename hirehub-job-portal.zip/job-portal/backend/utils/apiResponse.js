/**
 * Sends a standard JSON response.
 *
 * Usage:
 *   sendResponse(res, 200, 'Jobs fetched', { jobs, total });
 */
const sendResponse = (res, statusCode, message, data = {}) => {
  res.status(statusCode).json({
    success: true,
    message,
    ...data,
  });
};

module.exports = sendResponse;
