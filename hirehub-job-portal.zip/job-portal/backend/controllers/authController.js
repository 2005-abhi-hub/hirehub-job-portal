const { validationResult } = require('express-validator');
const User = require('../models/User');
const { generateToken } = require('../config/jwt');
const ApiError = require('../utils/apiError');
const sendResponse = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// ─── Register ────────────────────────────────────────────────────────────────
exports.register = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email, password } = req.body;

  if (await User.findOne({ email })) {
    throw new ApiError(400, 'An account with this email already exists');
  }

  const user = await User.create({ name, email, password });

  sendResponse(res, 201, 'Account created successfully', {
    token: generateToken(user._id),
    user: { _id: user._id, name: user.name, email: user.email, role: user.role },
  });
});

// ─── Login ────────────────────────────────────────────────────────────────────
exports.login = asyncHandler(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;

  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    throw new ApiError(401, 'Invalid email or password');
  }
  if (!user.isActive) {
    throw new ApiError(403, 'Your account has been deactivated. Contact support.');
  }

  sendResponse(res, 200, 'Login successful', {
    token: generateToken(user._id),
    user: { _id: user._id, name: user.name, email: user.email, role: user.role, avatar: user.avatar },
  });
});

// ─── Get current user (me) ────────────────────────────────────────────────────
exports.getMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)
    .populate('savedJobs', 'title company location type');
  sendResponse(res, 200, 'User fetched', user.toObject());
});

// ─── Update profile ───────────────────────────────────────────────────────────
exports.updateProfile = asyncHandler(async (req, res) => {
  const allowed = ['name', 'bio', 'phone', 'location', 'skills', 'linkedIn', 'portfolio', 'resume'];
  const updates = {};
  allowed.forEach((field) => {
    if (req.body[field] !== undefined) updates[field] = req.body[field];
  });

  const user = await User.findByIdAndUpdate(req.user._id, updates, {
    new: true,
    runValidators: true,
  });

  sendResponse(res, 200, 'Profile updated', user.toObject());
});

// ─── Change password ──────────────────────────────────────────────────────────
exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.matchPassword(currentPassword))) {
    throw new ApiError(400, 'Current password is incorrect');
  }

  user.password = newPassword;
  await user.save();

  sendResponse(res, 200, 'Password updated successfully');
});

// ─── Toggle saved job ─────────────────────────────────────────────────────────
exports.toggleSaveJob = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  const jobId = req.params.jobId;

  const idx = user.savedJobs.indexOf(jobId);
  if (idx > -1) {
    user.savedJobs.splice(idx, 1);
    await user.save();
    return sendResponse(res, 200, 'Job removed from saved', { saved: false });
  }

  user.savedJobs.push(jobId);
  await user.save();
  sendResponse(res, 200, 'Job saved successfully', { saved: true });
});
