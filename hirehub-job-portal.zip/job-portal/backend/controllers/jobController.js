const Job = require('../models/Job');
const ApiError = require('../utils/apiError');
const sendResponse = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// ─── GET /api/jobs  (public, with filters + pagination) ──────────────────────
exports.getJobs = asyncHandler(async (req, res) => {
  const {
    search, category, type, location,
    experience, minSalary, maxSalary,
    page = 1, limit = 10, sort = '-createdAt',
  } = req.query;

  const query = { isActive: true };

  if (search)      query.$text = { $search: search };
  if (category && category !== 'All') query.category = category;
  if (type     && type     !== 'All') query.type     = type;
  if (experience && experience !== 'All') query.experienceLevel = experience;
  if (location)    query.location = { $regex: location, $options: 'i' };
  if (minSalary)   query['salary.min'] = { $gte: Number(minSalary) };
  if (maxSalary)   query['salary.max'] = { $lte: Number(maxSalary) };

  const skip  = (Number(page) - 1) * Number(limit);
  const total = await Job.countDocuments(query);
  const jobs  = await Job.find(query)
    .populate('postedBy', 'name email')
    .sort(sort)
    .skip(skip)
    .limit(Number(limit));

  sendResponse(res, 200, 'Jobs fetched', {
    jobs, total, page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// ─── GET /api/jobs/featured ───────────────────────────────────────────────────
exports.getFeaturedJobs = asyncHandler(async (req, res) => {
  const jobs = await Job.find({ isActive: true, featured: true })
    .populate('postedBy', 'name')
    .limit(6);
  sendResponse(res, 200, 'Featured jobs fetched', { jobs });
});

// ─── GET /api/jobs/:id ────────────────────────────────────────────────────────
exports.getJobById = asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate('postedBy', 'name email');
  if (!job) throw new ApiError(404, 'Job not found');

  // Increment view counter (fire-and-forget)
  Job.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } }).exec();

  sendResponse(res, 200, 'Job fetched', job.toObject());
});

// ─── POST /api/jobs  (admin only) ─────────────────────────────────────────────
exports.createJob = asyncHandler(async (req, res) => {
  const job = await Job.create({ ...req.body, postedBy: req.user._id });
  sendResponse(res, 201, 'Job created successfully', job.toObject());
});

// ─── PUT /api/jobs/:id  (admin only) ─────────────────────────────────────────
exports.updateJob = asyncHandler(async (req, res) => {
  const job = await Job.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!job) throw new ApiError(404, 'Job not found');
  sendResponse(res, 200, 'Job updated', job.toObject());
});

// ─── DELETE /api/jobs/:id  (admin only) ──────────────────────────────────────
exports.deleteJob = asyncHandler(async (req, res) => {
  const job = await Job.findByIdAndDelete(req.params.id);
  if (!job) throw new ApiError(404, 'Job not found');
  sendResponse(res, 200, 'Job deleted successfully');
});
