const Application = require('../models/Application');
const Job = require('../models/Job');
const ApiError = require('../utils/apiError');
const sendResponse = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// ─── POST /api/applications  — apply for a job ────────────────────────────────
exports.applyForJob = asyncHandler(async (req, res) => {
  const { jobId, coverLetter, resume } = req.body;

  const job = await Job.findById(jobId);
  if (!job || !job.isActive) throw new ApiError(404, 'Job not found or no longer active');

  const existing = await Application.findOne({ job: jobId, applicant: req.user._id });
  if (existing) throw new ApiError(400, 'You have already applied for this job');

  const application = await Application.create({
    job: jobId,
    applicant: req.user._id,
    coverLetter,
    resume: resume || req.user.resume || '',
  });

  // Increment application counter on the job
  await Job.findByIdAndUpdate(jobId, { $inc: { applicationCount: 1 } });

  await application.populate([
    { path: 'job',       select: 'title company location' },
    { path: 'applicant', select: 'name email' },
  ]);

  sendResponse(res, 201, 'Application submitted successfully', application.toObject());
});

// ─── GET /api/applications/my ─────────────────────────────────────────────────
exports.getMyApplications = asyncHandler(async (req, res) => {
  const applications = await Application.find({ applicant: req.user._id })
    .populate('job', 'title company location type salary companyLogo')
    .sort('-appliedAt');
  sendResponse(res, 200, 'Applications fetched', { applications });
});

// ─── GET /api/applications/check/:jobId ──────────────────────────────────────
exports.checkApplication = asyncHandler(async (req, res) => {
  const application = await Application.findOne({
    job: req.params.jobId,
    applicant: req.user._id,
  });
  sendResponse(res, 200, 'Check complete', { applied: !!application, application });
});

// ─── PUT /api/applications/:id/withdraw ──────────────────────────────────────
exports.withdrawApplication = asyncHandler(async (req, res) => {
  const application = await Application.findOne({
    _id: req.params.id,
    applicant: req.user._id,
  });
  if (!application) throw new ApiError(404, 'Application not found');
  if (application.status !== 'pending') {
    throw new ApiError(400, 'You can only withdraw a pending application');
  }

  application.status = 'withdrawn';
  await application.save();
  sendResponse(res, 200, 'Application withdrawn', application.toObject());
});

// ─── GET /api/applications  (admin) ──────────────────────────────────────────
exports.getAllApplications = asyncHandler(async (req, res) => {
  const { status, jobId, page = 1, limit = 20 } = req.query;

  const query = {};
  if (status) query.status = status;
  if (jobId)  query.job    = jobId;

  const total = await Application.countDocuments(query);
  const applications = await Application.find(query)
    .populate('job',       'title company')
    .populate('applicant', 'name email location skills resume')
    .sort('-appliedAt')
    .skip((Number(page) - 1) * Number(limit))
    .limit(Number(limit));

  sendResponse(res, 200, 'Applications fetched', {
    applications, total,
    page:  Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// ─── PUT /api/applications/:id/status  (admin) ───────────────────────────────
exports.updateApplicationStatus = asyncHandler(async (req, res) => {
  const { status, adminNotes, interviewDate } = req.body;

  const update = { status };
  if (adminNotes    !== undefined) update.adminNotes    = adminNotes;
  if (interviewDate !== undefined) update.interviewDate = interviewDate;

  const application = await Application.findByIdAndUpdate(
    req.params.id,
    update,
    { new: true }
  ).populate('job applicant');

  if (!application) throw new ApiError(404, 'Application not found');
  sendResponse(res, 200, 'Status updated', application.toObject());
});
