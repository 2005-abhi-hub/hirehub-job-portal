const User = require('../models/User');
const Job = require('../models/Job');
const Application = require('../models/Application');
const ApiError = require('../utils/apiError');
const sendResponse = require('../utils/apiResponse');
const asyncHandler = require('../utils/asyncHandler');

// ─── GET /api/admin/stats ─────────────────────────────────────────────────────
exports.getStats = asyncHandler(async (req, res) => {
  const [
    totalUsers,
    totalJobs,
    totalApplications,
    activeJobs,
    recentApplications,
    applicationsByStatus,
    jobsByCategory,
  ] = await Promise.all([
    User.countDocuments({ role: 'jobseeker' }),
    Job.countDocuments(),
    Application.countDocuments(),
    Job.countDocuments({ isActive: true }),
    Application.find()
      .sort('-createdAt')
      .limit(5)
      .populate('job',       'title company')
      .populate('applicant', 'name email'),
    Application.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]),
    Job.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort:  { count: -1 } },
    ]),
  ]);

  sendResponse(res, 200, 'Stats fetched', {
    totalUsers, totalJobs, totalApplications, activeJobs,
    recentApplications, applicationsByStatus, jobsByCategory,
  });
});

// ─── GET /api/admin/users ─────────────────────────────────────────────────────
exports.getUsers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, search, role } = req.query;

  const query = {};
  if (search) {
    query.$or = [
      { name:  { $regex: search, $options: 'i' } },
      { email: { $regex: search, $options: 'i' } },
    ];
  }
  if (role) query.role = role;

  const total = await User.countDocuments(query);
  const users = await User.find(query)
    .sort('-createdAt')
    .skip((Number(page) - 1) * Number(limit))
    .limit(Number(limit));

  sendResponse(res, 200, 'Users fetched', { users, total });
});

// ─── PUT /api/admin/users/:id/toggle ─────────────────────────────────────────
exports.toggleUserStatus = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'User not found');

  user.isActive = !user.isActive;
  await user.save();

  sendResponse(res, 200, `User ${user.isActive ? 'activated' : 'deactivated'}`, { user });
});

// ─── PUT /api/admin/users/:id/role ────────────────────────────────────────────
exports.updateUserRole = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { role: req.body.role },
    { new: true }
  );
  if (!user) throw new ApiError(404, 'User not found');
  sendResponse(res, 200, 'Role updated', { user });
});

// ─── DELETE /api/admin/users/:id ─────────────────────────────────────────────
exports.deleteUser = asyncHandler(async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  await Application.deleteMany({ applicant: req.params.id });
  sendResponse(res, 200, 'User and their applications deleted');
});
