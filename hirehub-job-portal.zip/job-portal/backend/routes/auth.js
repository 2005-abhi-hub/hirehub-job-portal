const express = require('express');
const { body } = require('express-validator');
const router  = express.Router();

const {
  register,
  login,
  getMe,
  updateProfile,
  changePassword,
  toggleSaveJob,
} = require('../controllers/authController');

const { protect } = require('../middleware/auth');

const registerRules = [
  body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
  body('email').isEmail().withMessage('Please enter a valid email'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
];

const loginRules = [
  body('email').isEmail().withMessage('Please enter a valid email'),
  body('password').notEmpty().withMessage('Password is required'),
];

router.post('/register',        registerRules, register);
router.post('/login',           loginRules,    login);
router.get('/me',               protect,       getMe);
router.put('/profile',          protect,       updateProfile);
router.put('/change-password',  protect,       changePassword);
router.post('/save-job/:jobId', protect,       toggleSaveJob);

module.exports = router;
