const express = require('express');
const router  = express.Router();

const {
  getStats,
  getUsers,
  toggleUserStatus,
  updateUserRole,
  deleteUser,
} = require('../controllers/adminController');

const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly);      // all admin routes require auth + admin role

router.get('/stats',             getStats);
router.get('/users',             getUsers);
router.put('/users/:id/toggle',  toggleUserStatus);
router.put('/users/:id/role',    updateUserRole);
router.delete('/users/:id',      deleteUser);

module.exports = router;
