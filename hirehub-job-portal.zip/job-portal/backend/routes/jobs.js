const express = require('express');
const router  = express.Router();

const {
  getJobs,
  getFeaturedJobs,
  getJobById,
  createJob,
  updateJob,
  deleteJob,
} = require('../controllers/jobController');

const { protect, adminOnly } = require('../middleware/auth');

router.get('/',          getJobs);
router.get('/featured',  getFeaturedJobs);
router.get('/:id',       getJobById);
router.post('/',         protect, adminOnly, createJob);
router.put('/:id',       protect, adminOnly, updateJob);
router.delete('/:id',    protect, adminOnly, deleteJob);

module.exports = router;
