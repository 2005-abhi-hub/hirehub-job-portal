const express = require('express');
const router  = express.Router();

const {
  applyForJob,
  getMyApplications,
  checkApplication,
  withdrawApplication,
  getAllApplications,
  updateApplicationStatus,
} = require('../controllers/applicationController');

const { protect, adminOnly } = require('../middleware/auth');

// Job-seeker routes
router.post('/',                    protect,              applyForJob);
router.get('/my',                   protect,              getMyApplications);
router.get('/check/:jobId',         protect,              checkApplication);
router.put('/:id/withdraw',         protect,              withdrawApplication);

// Admin routes
router.get('/',                     protect, adminOnly,   getAllApplications);
router.put('/:id/status',           protect, adminOnly,   updateApplicationStatus);

module.exports = router;
