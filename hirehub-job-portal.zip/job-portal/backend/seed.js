const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('./models/User');
const Job = require('./models/Job');
const Application = require('./models/Application');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal');
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Job.deleteMany({});
    await Application.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Create admin user
    const admin = await User.create({
      name: 'Admin User',
      email: 'admin@hirehub.com',
      password: 'admin123',
      role: 'admin',
      location: 'San Francisco, CA',
    });

    // Create sample job seekers
    const seeker1 = await User.create({
      name: 'Alice Johnson',
      email: 'alice@example.com',
      password: 'password123',
      role: 'jobseeker',
      bio: 'Experienced frontend developer passionate about React and TypeScript.',
      skills: ['React', 'TypeScript', 'CSS', 'Node.js'],
      location: 'New York, NY',
    });

    const seeker2 = await User.create({
      name: 'Bob Smith',
      email: 'bob@example.com',
      password: 'password123',
      role: 'jobseeker',
      bio: 'Full-stack developer with 3 years experience.',
      skills: ['Python', 'Django', 'PostgreSQL', 'Docker'],
      location: 'Austin, TX',
    });

    console.log('👤 Created users');

    // Create sample jobs
    const jobs = await Job.insertMany([
      {
        title: 'Senior React Developer',
        company: 'TechCorp Inc.',
        description: 'We are looking for a skilled Senior React Developer to join our growing team. You will be responsible for building and maintaining high-quality web applications using React, TypeScript, and modern tooling.\n\nThis is a fantastic opportunity to work on challenging problems in a collaborative, fast-paced environment.',
        type: 'full-time',
        location: 'San Francisco, CA',
        category: 'Technology',
        experienceLevel: 'senior',
        salary: { min: 130000, max: 180000, currency: 'USD', period: 'yearly' },
        skills: ['React', 'TypeScript', 'Redux', 'GraphQL', 'Jest'],
        requirements: [
          '5+ years of React experience',
          'Strong TypeScript proficiency',
          'Experience with state management (Redux/Zustand)',
          'Familiarity with GraphQL',
          'Excellent communication skills',
        ],
        responsibilities: [
          'Lead frontend architecture decisions',
          'Mentor junior developers',
          'Collaborate with design and product teams',
          'Write maintainable, well-tested code',
        ],
        benefits: ['Health & dental insurance', '401k matching', 'Remote work options', 'Annual learning budget $2,000', 'Stock options'],
        featured: true,
        postedBy: admin._id,
        isActive: true,
      },
      {
        title: 'UX/UI Designer',
        company: 'DesignStudio',
        description: 'Join our world-class design team to craft beautiful, user-centered digital experiences. You will work closely with product managers and engineers to define, prototype, and ship features that millions of users love.',
        type: 'full-time',
        location: 'Remote',
        category: 'Design',
        experienceLevel: 'mid',
        salary: { min: 90000, max: 120000, currency: 'USD', period: 'yearly' },
        skills: ['Figma', 'Sketch', 'Prototyping', 'User Research', 'Design Systems'],
        requirements: [
          '3+ years of product design experience',
          'Expert Figma skills',
          'Portfolio showcasing UX process',
          'Experience with design systems',
        ],
        responsibilities: [
          'Design intuitive user interfaces',
          'Conduct user research and usability testing',
          'Maintain and evolve the design system',
          'Collaborate closely with engineering',
        ],
        benefits: ['Fully remote', 'Flexible hours', 'Top-of-market salary', 'Home office stipend'],
        featured: true,
        postedBy: admin._id,
        isActive: true,
      },
      {
        title: 'Backend Node.js Engineer',
        company: 'CloudSoft',
        description: 'We need a talented Backend Engineer to help us scale our Node.js microservices. You will design and build APIs consumed by thousands of clients daily.',
        type: 'full-time',
        location: 'Austin, TX',
        category: 'Technology',
        experienceLevel: 'mid',
        salary: { min: 100000, max: 140000, currency: 'USD', period: 'yearly' },
        skills: ['Node.js', 'Express', 'MongoDB', 'Redis', 'Docker', 'AWS'],
        requirements: [
          '3+ years Node.js experience',
          'Strong understanding of REST and GraphQL APIs',
          'Experience with cloud platforms (AWS/GCP)',
          'Knowledge of microservices architecture',
        ],
        responsibilities: [
          'Design and implement RESTful APIs',
          'Optimize database queries and caching strategies',
          'Ensure security best practices',
          'Participate in code reviews',
        ],
        benefits: ['Hybrid work', 'Health benefits', 'Quarterly bonuses', 'Conference budget'],
        postedBy: admin._id,
        isActive: true,
      },
      {
        title: 'Digital Marketing Manager',
        company: 'GrowthLab',
        description: 'Drive our digital marketing strategy across SEO, SEM, social media, and email. You will own our customer acquisition funnel and help us scale from 10k to 100k users.',
        type: 'full-time',
        location: 'New York, NY',
        category: 'Marketing',
        experienceLevel: 'senior',
        salary: { min: 85000, max: 115000, currency: 'USD', period: 'yearly' },
        skills: ['SEO', 'Google Ads', 'HubSpot', 'Analytics', 'Content Strategy'],
        requirements: [
          '5+ years digital marketing experience',
          'Proven growth track record',
          'Strong analytical skills',
          'Experience with marketing automation tools',
        ],
        responsibilities: [
          'Own the digital acquisition strategy',
          'Manage paid ad campaigns across channels',
          'Analyze and optimize conversion funnels',
          'Lead a team of 3 marketing specialists',
        ],
        benefits: ['Performance bonuses', 'Health coverage', 'Flexible PTO'],
        postedBy: admin._id,
        isActive: true,
      },
      {
        title: 'Data Science Intern',
        company: 'AI Ventures',
        description: 'Exciting internship opportunity for students or fresh graduates looking to gain hands-on experience in machine learning and data analysis.',
        type: 'internship',
        location: 'Boston, MA',
        category: 'Technology',
        experienceLevel: 'entry',
        salary: { min: 25, max: 35, currency: 'USD', period: 'hourly' },
        skills: ['Python', 'Pandas', 'Scikit-learn', 'SQL', 'Jupyter'],
        requirements: [
          'Pursuing or recently completed CS/Statistics degree',
          'Python proficiency',
          'Basic ML knowledge',
          'Familiarity with SQL',
        ],
        responsibilities: [
          'Assist with data cleaning and preprocessing',
          'Build and evaluate ML models',
          'Create data visualizations',
          'Present findings to the team',
        ],
        benefits: ['Paid internship', 'Mentorship program', 'Potential full-time offer'],
        postedBy: admin._id,
        isActive: true,
      },
      {
        title: 'Product Manager',
        company: 'StartupX',
        description: 'We are looking for a product-minded PM to lead our core product. You will work at the intersection of business, technology, and user experience to deliver products customers love.',
        type: 'full-time',
        location: 'Remote',
        category: 'Operations',
        experienceLevel: 'senior',
        salary: { min: 120000, max: 160000, currency: 'USD', period: 'yearly' },
        skills: ['Product Strategy', 'Agile', 'Data Analysis', 'Roadmapping', 'Figma'],
        requirements: [
          '5+ years PM experience',
          'Track record of shipping successful products',
          'Strong data-driven decision making',
          'Excellent stakeholder management',
        ],
        responsibilities: [
          'Define product vision and roadmap',
          'Write clear product specifications',
          'Prioritize features based on user and business impact',
          'Work closely with engineering and design',
        ],
        benefits: ['Equity package', 'Fully remote', 'Unlimited PTO', '$150k+ salary'],
        featured: true,
        postedBy: admin._id,
        isActive: true,
      },
    ]);

    console.log(`💼 Created ${jobs.length} jobs`);

    // Create sample applications
    await Application.insertMany([
      {
        job: jobs[0]._id,
        applicant: seeker1._id,
        coverLetter: 'I am excited to apply for the Senior React Developer role at TechCorp. With 6 years of React experience and a passion for building scalable frontends, I believe I would be an excellent fit for your team. I have worked on large-scale applications serving millions of users and am experienced with the entire modern React ecosystem.',
        status: 'reviewing',
        adminNotes: 'Strong candidate, schedule technical interview.',
      },
      {
        job: jobs[2]._id,
        applicant: seeker2._id,
        coverLetter: 'I am very interested in the Backend Node.js Engineer position at CloudSoft. I have 3 years of experience building microservices and REST APIs with Node.js and MongoDB. I have a deep understanding of distributed systems and would love to contribute to your scaling efforts.',
        status: 'shortlisted',
        interviewDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
      {
        job: jobs[1]._id,
        applicant: seeker1._id,
        coverLetter: 'As a developer with a deep appreciation for design systems, I would love to collaborate with the DesignStudio team. While my primary background is engineering, I have worked closely with designers and understand Figma workflows thoroughly.',
        status: 'pending',
      },
    ]);

    console.log('📋 Created sample applications');
    console.log('\n✅ Seed completed successfully!\n');
    console.log('🔑 Login credentials:');
    console.log('   Admin:     admin@hirehub.com / admin123');
    console.log('   Seeker 1:  alice@example.com / password123');
    console.log('   Seeker 2:  bob@example.com / password123\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err);
    process.exit(1);
  }
};

seed();
