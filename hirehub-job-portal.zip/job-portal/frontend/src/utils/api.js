import axios from 'axios';

/**
 * Central Axios instance.
 * All services import this — never import axios directly in components.
 */
const API = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
  timeout: 10000,
});

// ── Request interceptor — attach JWT token ────────────────────────────────────
API.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response interceptor — handle 401 globally ───────────────────────────────
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default API;

// ── Legacy named exports (keeps old imports working) ─────────────────────────
import authService        from '../services/authService';
import jobService         from '../services/jobService';
import applicationService from '../services/applicationService';
import adminService       from '../services/adminService';

export const authAPI         = authService;
export const jobsAPI         = jobService;
export const applicationsAPI = applicationService;
export const adminAPI        = adminService;
