import { useState, useEffect } from 'react';

/**
 * Delays updating a value until the user stops typing.
 * Useful for search inputs to avoid firing on every keystroke.
 *
 * @param {any}    value — the value to debounce
 * @param {number} delay — milliseconds to wait (default 400ms)
 */
const useDebounce = (value, delay = 400) => {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
};

export default useDebounce;
