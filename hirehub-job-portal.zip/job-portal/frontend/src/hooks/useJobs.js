import { useState, useEffect, useCallback } from 'react';
import { jobService } from '../services';
import toast from 'react-hot-toast';

const useJobs = (initialFilters = {}) => {
  const [jobs, setJobs]       = useState([]);
  const [total, setTotal]     = useState(0);
  const [pages, setPages]     = useState(1);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search:'', category:'', type:'', location:'',
    experience:'', page:1, limit:10, sort:'-createdAt',
    ...initialFilters,
  });

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(
        Object.entries(filters).filter(([, v]) => v !== '' && v !== 'All')
      );
      const res = await jobService.getAll(params);
      setJobs(res.data.jobs);
      setTotal(res.data.total);
      setPages(res.data.pages);
    } catch {
      toast.error('Failed to load jobs');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => { fetchJobs(); }, [fetchJobs]);

  const setFilter = (key, value) =>
    setFilters(prev => ({ ...prev, [key]: value, page: key !== 'page' ? 1 : value }));

  const resetFilters = () =>
    setFilters({ search:'', category:'', type:'', location:'', experience:'', page:1, limit:10, sort:'-createdAt' });

  return { jobs, total, pages, loading, filters, setFilter, resetFilters, refetch: fetchJobs };
};

export default useJobs;
