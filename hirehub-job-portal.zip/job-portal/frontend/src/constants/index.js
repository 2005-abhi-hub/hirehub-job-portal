export const CATEGORIES = [
  'Technology','Marketing','Design','Finance',
  'Healthcare','Education','Sales','Engineering',
  'HR','Operations','Other',
];

export const CATEGORY_ICONS = {
  Technology:'💻', Design:'🎨', Marketing:'📣', Finance:'💹',
  Healthcare:'🏥', Engineering:'⚙️', Sales:'🤝', HR:'👥',
  Education:'📚', Operations:'🏗️', Other:'🌐',
};

export const JOB_TYPES = ['full-time','part-time','contract','internship','remote'];

export const JOB_TYPE_COLORS = {
  'full-time':'badge-green','part-time':'badge-blue',
  'contract':'badge-amber','internship':'badge-purple','remote':'badge-green',
};

export const EXPERIENCE_LEVELS = ['entry','mid','senior','lead','executive'];

export const EXPERIENCE_LABELS = {
  entry:'Entry Level', mid:'Mid Level', senior:'Senior Level',
  lead:'Lead', executive:'Executive',
};

export const APPLICATION_STATUSES = [
  'pending','reviewing','shortlisted','interview','offered','rejected','withdrawn',
];

export const STATUS_CONFIG = {
  pending:    { label:'Pending',     badgeClass:'badge-gray',   icon:'⏳' },
  reviewing:  { label:'Reviewing',   badgeClass:'badge-blue',   icon:'👀' },
  shortlisted:{ label:'Shortlisted', badgeClass:'badge-purple', icon:'⭐' },
  interview:  { label:'Interview',   badgeClass:'badge-amber',  icon:'📅' },
  offered:    { label:'Offered',     badgeClass:'badge-green',  icon:'🎉' },
  rejected:   { label:'Rejected',    badgeClass:'badge-red',    icon:'✗'  },
  withdrawn:  { label:'Withdrawn',   badgeClass:'badge-gray',   icon:'↩'  },
};

export const SALARY_PERIODS = ['hourly','monthly','yearly'];
export const DEFAULT_PAGE_SIZE = 10;
