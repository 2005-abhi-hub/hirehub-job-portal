import React, { useState, useEffect } from 'react';
import { Link, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AdminOverview from './admin/AdminOverview';
import AdminJobs from './admin/AdminJobs';
import AdminApplications from './admin/AdminApplications';
import AdminUsers from './admin/AdminUsers';
import './AdminDashboard.css';

const navItems = [
  { path: '/admin', label: 'Overview', icon: '📊', exact: true },
  { path: '/admin/jobs', label: 'Jobs', icon: '💼' },
  { path: '/admin/applications', label: 'Applications', icon: '📋' },
  { path: '/admin/users', label: 'Users', icon: '👥' },
];

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isActive = (item) => item.exact ? location.pathname === item.path : location.pathname.startsWith(item.path);

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <aside className={`admin-sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="admin-brand">
          <span className="logo-icon">⬡</span>
          <span>HireHub</span>
          <span className="admin-tag">Admin</span>
        </div>

        <nav className="admin-nav">
          {navItems.map(item => (
            <Link key={item.path} to={item.path} className={`admin-nav-item ${isActive(item) ? 'active' : ''}`} onClick={() => setSidebarOpen(false)}>
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="admin-sidebar-footer">
          <div className="admin-user">
            <div className="admin-user-avatar">{user?.name?.charAt(0)}</div>
            <div>
              <p className="admin-user-name">{user?.name}</p>
              <p className="admin-user-role">Administrator</p>
            </div>
          </div>
          <div className="admin-footer-actions">
            <Link to="/" className="footer-link">← Site</Link>
            <button onClick={() => { logout(); navigate('/'); }} className="footer-link logout">Sign Out</button>
          </div>
        </div>
      </aside>

      {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />}

      {/* Main Content */}
      <div className="admin-main">
        <header className="admin-topbar">
          <button className="mobile-menu-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
          <div className="topbar-breadcrumb">
            {navItems.find(i => isActive(i))?.label || 'Dashboard'}
          </div>
          <div className="topbar-right">
            <span className="topbar-date">{new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
          </div>
        </header>

        <div className="admin-content">
          <Routes>
            <Route path="/" element={<AdminOverview />} />
            <Route path="/jobs/*" element={<AdminJobs />} />
            <Route path="/applications" element={<AdminApplications />} />
            <Route path="/users" element={<AdminUsers />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}
