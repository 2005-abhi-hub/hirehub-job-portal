import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import useApplications from '../hooks/useApplications';
import { STATUS_CONFIG } from '../constants';
import toast from 'react-hot-toast';
import './MyApplications.css';

export default function MyApplications() {
  const { applications, loading, withdraw } = useApplications();
  const [filter, setFilter] = useState('all');

  const handleWithdraw = async (id) => {
    if (!window.confirm('Withdraw this application?')) return;
    try {
      await withdraw(id);
      toast.success('Application withdrawn');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to withdraw');
    }
  };

  const filtered = filter === 'all'
    ? applications
    : applications.filter(a => a.status === filter);

  const counts = applications.reduce((acc, a) => {
    acc[a.status] = (acc[a.status] || 0) + 1;
    return acc;
  }, {});

  if (loading) return <div className="page-loader"><div className="loading-spinner" /></div>;

  return (
    <div className="my-apps-page fade-in">
      <div className="container">
        <div className="page-header">
          <div>
            <h1>My Applications</h1>
            <p className="page-subtitle">{applications.length} total applications</p>
          </div>
          <Link to="/jobs" className="btn btn-primary">Browse More Jobs</Link>
        </div>

        {/* Status filter chips */}
        <div className="app-stats-row">
          <button className={`stat-chip ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}>
            All <span className="badge badge-gray">{applications.length}</span>
          </button>
          {Object.entries(STATUS_CONFIG).map(([key, cfg]) => counts[key] ? (
            <button key={key} className={`stat-chip ${filter === key ? 'active' : ''}`}
              onClick={() => setFilter(filter === key ? 'all' : key)}>
              {cfg.icon} {cfg.label}
              <span className={`badge ${cfg.badgeClass}`}>{counts[key]}</span>
            </button>
          ) : null)}
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <div style={{ fontSize: '3rem' }}>📋</div>
            <h3>{filter === 'all' ? 'No applications yet' : `No ${filter} applications`}</h3>
            <p>{filter === 'all' ? 'Start applying for jobs to see them here' : 'Try viewing all applications'}</p>
            {filter === 'all' && <Link to="/jobs" className="btn btn-primary" style={{ marginTop: 12 }}>Find Jobs</Link>}
          </div>
        ) : (
          <div className="apps-list">
            {filtered.map(app => {
              const cfg = STATUS_CONFIG[app.status] || STATUS_CONFIG.pending;
              return (
                <div key={app._id} className="app-card fade-in">
                  <div className="app-card-left">
                    <div className="app-company-avatar">
                      {app.job?.company?.charAt(0) || '?'}
                    </div>
                    <div className="app-info">
                      <h3 className="app-job-title">
                        <Link to={`/jobs/${app.job?._id}`}>{app.job?.title || 'Job Removed'}</Link>
                      </h3>
                      <p className="app-company">{app.job?.company}</p>
                      <div className="app-meta">
                        {app.job?.location && <span>📍 {app.job.location}</span>}
                        {app.job?.type    && <span className="badge badge-gray">{app.job.type}</span>}
                        <span>Applied {new Date(app.appliedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="app-card-right">
                    <span className={`badge ${cfg.badgeClass} status-badge`}>
                      {cfg.icon} {cfg.label}
                    </span>
                    {app.interviewDate && (
                      <p className="interview-date">
                        📅 Interview: {new Date(app.interviewDate).toLocaleDateString()}
                      </p>
                    )}
                    {app.adminNotes && (
                      <div className="admin-note"><p>💬 {app.adminNotes}</p></div>
                    )}
                    {app.status === 'pending' && (
                      <button onClick={() => handleWithdraw(app._id)}
                        className="btn btn-danger btn-sm">Withdraw</button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
