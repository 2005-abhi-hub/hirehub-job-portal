import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import jobService from '../services/jobService';
import JobCard from '../components/JobCard';
import useSavedJobs from '../hooks/useSavedJobs';
import { useAuth } from '../context/AuthContext';
import { CATEGORY_ICONS } from '../constants';
import './Home.css';

const FEATURED_CATS = ['Technology','Design','Marketing','Finance','Healthcare','Engineering','Sales','HR'];

export default function Home() {
  const [latestJobs, setLatestJobs] = useState([]);
  const [totalJobs,  setTotalJobs]  = useState(0);
  const [search,     setSearch]     = useState('');
  const [location,   setLocation]   = useState('');
  const { isSaved, toggleSave }     = useSavedJobs();
  const { user }                    = useAuth();
  const navigate                    = useNavigate();

  useEffect(() => {
    jobService.getAll({ limit: 6, sort: '-createdAt' })
      .then(res => {
        setLatestJobs(res.data.jobs);
        setTotalJobs(res.data.total);
      })
      .catch(() => {});
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (search)   params.set('search',   search);
    if (location) params.set('location', location);
    navigate(`/jobs?${params.toString()}`);
  };

  return (
    <div className="home fade-in">
      {/* ── Hero ── */}
      <section className="hero">
        <div className="hero-grid-bg" />
        <div className="container hero-content">
          <div className="hero-badge">🚀 {totalJobs}+ jobs available</div>
          <h1 className="hero-title">
            Find Your Next<br />
            <span className="gradient-text">Dream Career</span>
          </h1>
          <p className="hero-subtitle">
            Connect with top companies. Discover opportunities that match your skills and ambitions.
          </p>
          <form className="search-bar" onSubmit={handleSearch}>
            <div className="search-input-wrap">
              <span className="search-icon">🔍</span>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Job title, skills, or keywords..."
              />
            </div>
            <div className="search-divider" />
            <div className="search-input-wrap">
              <span className="search-icon">📍</span>
              <input
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="City or remote..."
              />
            </div>
            <button type="submit" className="btn btn-primary btn-lg search-btn">
              Search Jobs
            </button>
          </form>
          <div className="hero-stats">
            <div className="stat"><strong>{totalJobs}+</strong><span>Open Roles</span></div>
            <div className="stat-divider" />
            <div className="stat"><strong>48+</strong><span>Companies</span></div>
            <div className="stat-divider" />
            <div className="stat"><strong>2,400+</strong><span>Hired</span></div>
          </div>
        </div>
      </section>

      {/* ── Categories ── */}
      <section className="section categories-section">
        <div className="container">
          <div className="section-header">
            <h2>Browse by Category</h2>
            <Link to="/jobs" className="see-all">See all jobs →</Link>
          </div>
          <div className="categories-grid">
            {FEATURED_CATS.map(cat => (
              <Link key={cat} to={`/jobs?category=${cat}`} className="category-card">
                <span className="cat-icon">{CATEGORY_ICONS[cat]}</span>
                <span className="cat-name">{cat}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Latest Jobs ── */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <h2>Latest Opportunities</h2>
            <Link to="/jobs" className="see-all">View all →</Link>
          </div>
          {latestJobs.length === 0 ? (
            <div className="empty-state">
              <div style={{ fontSize: '2.5rem' }}>🔍</div>
              <p>No jobs posted yet. Check back soon!</p>
            </div>
          ) : (
            <div className="jobs-grid">
              {latestJobs.map(job => (
                <JobCard
                  key={job._id}
                  job={job}
                  saved={isSaved(job._id)}
                  onSave={toggleSave}
                />
              ))}
            </div>
          )}
          <div className="center-cta">
            <Link to="/jobs" className="btn btn-outline btn-lg">Browse All Jobs</Link>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      {!user && (
        <section className="cta-section">
          <div className="container">
            <div className="cta-card">
              <div className="cta-glow" />
              <h2>Ready to Land Your Dream Job?</h2>
              <p>Join thousands of professionals who found their perfect role through HireHub.</p>
              <div className="cta-buttons">
                <Link to="/register" className="btn btn-primary btn-lg">Create Free Account</Link>
                <Link to="/jobs"     className="btn btn-outline btn-lg">Explore Jobs</Link>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
