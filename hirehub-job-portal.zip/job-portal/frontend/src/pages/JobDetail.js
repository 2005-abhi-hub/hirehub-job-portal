import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { jobsAPI, applicationsAPI } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import './JobDetail.css';

export default function JobDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applied, setApplied] = useState(false);
  const [applicationId, setApplicationId] = useState(null);
  const [showApplyForm, setShowApplyForm] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    jobsAPI.getById(id).then(res => { setJob(res.data); setLoading(false); }).catch(() => { toast.error('Job not found'); navigate('/jobs'); });
    if (user) {
      applicationsAPI.check(id).then(res => { setApplied(res.data.applied); setApplicationId(res.data.application?._id); }).catch(() => {});
    }
  }, [id, user, navigate]);

  const handleApply = async (e) => {
    e.preventDefault();
    if (!user) { toast.error('Please sign in to apply'); navigate('/login'); return; }
    if (!coverLetter.trim()) { toast.error('Cover letter is required'); return; }
    setSubmitting(true);
    try {
      await applicationsAPI.apply({ jobId: id, coverLetter });
      setApplied(true);
      setShowApplyForm(false);
      toast.success('Application submitted successfully! 🎉');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit application');
    } finally { setSubmitting(false); }
  };

  const handleWithdraw = async () => {
    if (!window.confirm('Withdraw your application?')) return;
    try {
      await applicationsAPI.withdraw(applicationId);
      setApplied(false);
      toast.success('Application withdrawn');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to withdraw'); }
  };

  if (loading) return <div className="page-loader"><div className="loading-spinner" /></div>;
  if (!job) return null;

  const salary = job.salary?.min || job.salary?.max
    ? `$${job.salary.min?.toLocaleString() || '?'} – $${job.salary.max?.toLocaleString() || '?'} / ${job.salary.period || 'year'}`
    : 'Not specified';

  return (
    <div className="job-detail-page fade-in">
      <div className="container">
        <div className="breadcrumb">
          <Link to="/jobs">Jobs</Link> / {job.category} / <span>{job.title}</span>
        </div>

        <div className="job-detail-layout">
          {/* Main Content */}
          <main className="job-detail-main">
            <div className="job-detail-header card">
              <div className="jd-company-row">
                <div className="jd-company-avatar">
                  {job.companyLogo ? <img src={job.companyLogo} alt={job.company} /> : <span>{job.company?.charAt(0)}</span>}
                </div>
                <div>
                  <h1 className="jd-title">{job.title}</h1>
                  <p className="jd-company">{job.company}</p>
                </div>
              </div>

              <div className="jd-meta-grid">
                <div className="jd-meta-item"><span>📍</span><span>{job.location}</span></div>
                <div className="jd-meta-item"><span>💼</span><span style={{ textTransform: 'capitalize' }}>{job.type}</span></div>
                <div className="jd-meta-item"><span>💰</span><span>{salary}</span></div>
                <div className="jd-meta-item"><span>📊</span><span style={{ textTransform: 'capitalize' }}>{job.experienceLevel} Level</span></div>
                <div className="jd-meta-item"><span>🏷️</span><span>{job.category}</span></div>
                <div className="jd-meta-item"><span>👥</span><span>{job.applicationCount} applicants</span></div>
              </div>

              {job.skills?.length > 0 && (
                <div className="jd-skills">
                  <p className="section-label">Required Skills</p>
                  <div className="skills-list">
                    {job.skills.map(s => <span key={s} className="skill-tag">{s}</span>)}
                  </div>
                </div>
              )}

              <div className="jd-apply-row">
                {applied ? (
                  <div className="applied-status">
                    <span className="badge badge-green">✓ Applied</span>
                    {applicationId && <button onClick={handleWithdraw} className="btn btn-outline btn-sm">Withdraw</button>}
                  </div>
                ) : (
                  <button className="btn btn-primary btn-lg" onClick={() => user ? setShowApplyForm(true) : navigate('/login')}>
                    Apply Now →
                  </button>
                )}
                {job.deadline && <p className="deadline">⏳ Deadline: {new Date(job.deadline).toLocaleDateString()}</p>}
              </div>
            </div>

            {/* Apply Form */}
            {showApplyForm && (
              <div className="apply-form card fade-in">
                <h3>Submit Your Application</h3>
                <form onSubmit={handleApply}>
                  <div className="form-group">
                    <label className="form-label">Cover Letter *</label>
                    <textarea
                      rows={8}
                      placeholder="Tell us why you're a great fit for this role..."
                      value={coverLetter}
                      onChange={e => setCoverLetter(e.target.value)}
                      required
                    />
                    <span className="form-hint">{coverLetter.length}/2000 characters</span>
                  </div>
                  {user?.resume && (
                    <div className="form-group">
                      <label className="form-label">Resume</label>
                      <p className="resume-preview">📎 {user.resume}</p>
                    </div>
                  )}
                  <div className="apply-form-actions">
                    <button type="button" className="btn btn-outline" onClick={() => setShowApplyForm(false)}>Cancel</button>
                    <button type="submit" className="btn btn-primary" disabled={submitting}>
                      {submitting ? 'Submitting...' : 'Submit Application'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            <div className="job-section card">
              <h2>Job Description</h2>
              <div className="job-description">{job.description}</div>
            </div>

            {job.responsibilities?.length > 0 && (
              <div className="job-section card">
                <h2>Responsibilities</h2>
                <ul className="bullet-list">
                  {job.responsibilities.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              </div>
            )}

            {job.requirements?.length > 0 && (
              <div className="job-section card">
                <h2>Requirements</h2>
                <ul className="bullet-list">
                  {job.requirements.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              </div>
            )}

            {job.benefits?.length > 0 && (
              <div className="job-section card">
                <h2>Benefits</h2>
                <ul className="bullet-list benefits">
                  {job.benefits.map((b, i) => <li key={i}><span className="benefit-icon">✦</span>{b}</li>)}
                </ul>
              </div>
            )}
          </main>

          {/* Sidebar */}
          <aside className="job-detail-sidebar">
            <div className="card sidebar-card">
              <h3>Job Overview</h3>
              <div className="overview-list">
                <div className="overview-item"><span className="ov-label">Posted</span><span>{new Date(job.createdAt).toLocaleDateString()}</span></div>
                <div className="overview-item"><span className="ov-label">Type</span><span className="badge badge-green" style={{ textTransform: 'capitalize' }}>{job.type}</span></div>
                <div className="overview-item"><span className="ov-label">Level</span><span style={{ textTransform: 'capitalize' }}>{job.experienceLevel}</span></div>
                <div className="overview-item"><span className="ov-label">Location</span><span>{job.location}</span></div>
                {job.salary?.min && <div className="overview-item"><span className="ov-label">Min Salary</span><span className="salary-text">${job.salary.min?.toLocaleString()}</span></div>}
                {job.salary?.max && <div className="overview-item"><span className="ov-label">Max Salary</span><span className="salary-text">${job.salary.max?.toLocaleString()}</span></div>}
                <div className="overview-item"><span className="ov-label">Views</span><span>{job.views}</span></div>
              </div>
              {!applied && (
                <button className="btn btn-primary" style={{ width: '100%', marginTop: 16 }}
                  onClick={() => user ? setShowApplyForm(true) : navigate('/login')}>
                  Apply Now
                </button>
              )}
            </div>

            {!user && (
              <div className="card sidebar-card">
                <h3>New to HireHub?</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginBottom: 12 }}>Create an account to apply for jobs and track your applications.</p>
                <Link to="/register" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', display: 'flex' }}>Create Account</Link>
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
