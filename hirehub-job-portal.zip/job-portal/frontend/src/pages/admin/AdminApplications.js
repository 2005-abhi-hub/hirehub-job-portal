import React, { useState, useEffect } from 'react';
import { applicationsAPI } from '../../utils/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

const STATUS_OPTIONS = ['pending', 'reviewing', 'shortlisted', 'interview', 'offered', 'rejected', 'withdrawn'];
const statusColors = {
  pending: 'badge-gray', reviewing: 'badge-blue', shortlisted: 'badge-purple',
  interview: 'badge-amber', offered: 'badge-green', rejected: 'badge-red', withdrawn: 'badge-gray'
};

export default function AdminApplications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [selected, setSelected] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const params = { page, limit: 15 };
      if (filter) params.status = filter;
      const res = await applicationsAPI.getAll(params);
      setApplications(res.data.applications);
      setTotal(res.data.total);
    } catch { toast.error('Failed to load applications'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchApplications(); }, [page, filter]);

  const handleStatusUpdate = async (id, status, adminNotes = '') => {
    setUpdatingId(id);
    try {
      const res = await applicationsAPI.updateStatus(id, { status, adminNotes });
      setApplications(prev => prev.map(a => a._id === id ? { ...a, status: res.data.status, adminNotes: res.data.adminNotes } : a));
      if (selected?._id === id) setSelected(prev => ({ ...prev, status, adminNotes }));
      toast.success('Status updated');
    } catch { toast.error('Failed to update status'); }
    finally { setUpdatingId(null); }
  };

  return (
    <div className="admin-page fade-in">
      <div className="admin-page-header">
        <div>
          <h1>Applications</h1>
          <p>{total} total applications</p>
        </div>
        <select value={filter} onChange={e => { setFilter(e.target.value); setPage(1); }} style={{ width: 180 }}>
          <option value="">All Statuses</option>
          {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>
      </div>

      <div className="admin-layout-split">
        {/* List */}
        <div className="admin-card applications-list-card">
          {loading ? (
            <div style={{ padding: 40, textAlign: 'center' }}><div className="loading-spinner" /></div>
          ) : applications.length === 0 ? (
            <div className="empty-state"><p>No applications found</p></div>
          ) : (
            <>
              <div className="applications-list">
                {applications.map(app => (
                  <div key={app._id} className={`application-row ${selected?._id === app._id ? 'selected' : ''}`} onClick={() => setSelected(app)}>
                    <div className="app-row-left">
                      <div className="app-mini-avatar">{app.applicant?.name?.charAt(0)}</div>
                      <div className="app-row-info">
                        <p className="app-row-name">{app.applicant?.name}</p>
                        <p className="app-row-job">{app.job?.title} @ {app.job?.company}</p>
                        <p className="app-row-date">{new Date(app.appliedAt || app.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <span className={`badge ${statusColors[app.status]}`}>{app.status}</span>
                  </div>
                ))}
              </div>
              {total > 15 && (
                <div className="pagination" style={{ padding: '12px 0 0' }}>
                  <button className="btn btn-outline btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Page {page}</span>
                  <button className="btn btn-outline btn-sm" disabled={applications.length < 15} onClick={() => setPage(p => p + 1)}>Next →</button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Detail Panel */}
        {selected ? (
          <div className="admin-card application-detail-card fade-in">
            <div className="detail-header">
              <div className="detail-avatar">{selected.applicant?.name?.charAt(0)}</div>
              <div>
                <h3 className="detail-name">{selected.applicant?.name}</h3>
                <p className="detail-email">{selected.applicant?.email}</p>
              </div>
              <button className="close-detail" onClick={() => setSelected(null)}>✕</button>
            </div>

            <div className="detail-job-info">
              <p className="detail-label">Applied For</p>
              <p className="detail-value">{selected.job?.title}</p>
              <p className="detail-sub">{selected.job?.company}</p>
            </div>

            <div className="detail-section">
              <p className="detail-label">Applied On</p>
              <p className="detail-value-sm">{new Date(selected.appliedAt || selected.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>

            <div className="detail-section">
              <p className="detail-label">Cover Letter</p>
              <div className="cover-letter-box">{selected.coverLetter}</div>
            </div>

            {selected.resume && (
              <div className="detail-section">
                <p className="detail-label">Resume</p>
                <a href={selected.resume} target="_blank" rel="noreferrer" className="resume-link">📎 View Resume →</a>
              </div>
            )}

            <div className="detail-section">
              <p className="detail-label">Update Status</p>
              <div className="status-buttons">
                {STATUS_OPTIONS.filter(s => s !== 'withdrawn').map(s => (
                  <button key={s} className={`status-btn ${selected.status === s ? 'active' : ''} status-${s}`}
                    onClick={() => handleStatusUpdate(selected._id, s)} disabled={updatingId === selected._id}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <AdminNoteInput
              initialNote={selected.adminNotes || ''}
              onSave={(note) => handleStatusUpdate(selected._id, selected.status, note)}
              saving={updatingId === selected._id}
            />
          </div>
        ) : (
          <div className="admin-card application-detail-card empty-detail">
            <div className="empty-state">
              <div style={{ fontSize: '2.5rem' }}>👈</div>
              <p>Select an application to review</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function AdminNoteInput({ initialNote, onSave, saving }) {
  const [note, setNote] = useState(initialNote);
  useEffect(() => setNote(initialNote), [initialNote]);
  return (
    <div className="detail-section">
      <p className="detail-label">Admin Note</p>
      <textarea rows={3} value={note} onChange={e => setNote(e.target.value)} placeholder="Internal note for this applicant..." style={{ marginBottom: 8 }} />
      <button className="btn btn-outline btn-sm" onClick={() => onSave(note)} disabled={saving}>Save Note</button>
    </div>
  );
}
