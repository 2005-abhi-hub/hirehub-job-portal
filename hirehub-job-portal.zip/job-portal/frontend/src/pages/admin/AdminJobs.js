import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { jobsAPI } from '../../utils/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

const CATEGORIES = ['Technology', 'Marketing', 'Design', 'Finance', 'Healthcare', 'Education', 'Sales', 'Engineering', 'HR', 'Operations', 'Other'];
const TYPES = ['full-time', 'part-time', 'contract', 'internship', 'remote'];
const EXPERIENCE = ['entry', 'mid', 'senior', 'lead', 'executive'];

function JobForm({ existing, onSave }) {
  const navigate = useNavigate();
  const [form, setForm] = useState(existing || {
    title: '', company: '', description: '', type: 'full-time', location: '',
    category: 'Technology', experienceLevel: 'mid',
    skills: '', requirements: '', responsibilities: '', benefits: '',
    'salary.min': '', 'salary.max': '', 'salary.period': 'yearly',
    deadline: '', featured: false, isActive: true,
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const data = {
      ...form,
      skills: typeof form.skills === 'string' ? form.skills.split(',').map(s => s.trim()).filter(Boolean) : form.skills,
      requirements: typeof form.requirements === 'string' ? form.requirements.split('\n').filter(Boolean) : form.requirements,
      responsibilities: typeof form.responsibilities === 'string' ? form.responsibilities.split('\n').filter(Boolean) : form.responsibilities,
      benefits: typeof form.benefits === 'string' ? form.benefits.split('\n').filter(Boolean) : form.benefits,
      salary: { min: Number(form['salary.min']) || undefined, max: Number(form['salary.max']) || undefined, period: form['salary.period'] },
    };
    try {
      if (existing?._id) await jobsAPI.update(existing._id, data);
      else await jobsAPI.create(data);
      toast.success(existing ? 'Job updated!' : 'Job created!');
      onSave?.();
      navigate('/admin/jobs');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save job'); }
    finally { setSaving(false); }
  };

  return (
    <div className="admin-page fade-in">
      <div className="admin-page-header">
        <div>
          <h1>{existing ? 'Edit Job' : 'Post New Job'}</h1>
          <p>{existing ? 'Update job details below' : 'Fill in the details to post a new job'}</p>
        </div>
        <Link to="/admin/jobs" className="btn btn-outline">← Back</Link>
      </div>

      <form onSubmit={handleSubmit} className="job-form admin-card">
        <div className="form-section-title">Basic Information</div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Job Title *</label>
            <input value={form.title} onChange={e => set('title', e.target.value)} required placeholder="e.g. Senior React Developer" />
          </div>
          <div className="form-group">
            <label className="form-label">Company *</label>
            <input value={form.company} onChange={e => set('company', e.target.value)} required placeholder="e.g. Acme Corp" />
          </div>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Category *</label>
            <select value={form.category} onChange={e => set('category', e.target.value)}>
              {CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Job Type *</label>
            <select value={form.type} onChange={e => set('type', e.target.value)}>
              {TYPES.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
            </select>
          </div>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Location *</label>
            <input value={form.location} onChange={e => set('location', e.target.value)} required placeholder="e.g. New York, NY or Remote" />
          </div>
          <div className="form-group">
            <label className="form-label">Experience Level *</label>
            <select value={form.experienceLevel} onChange={e => set('experienceLevel', e.target.value)}>
              {EXPERIENCE.map(e => <option key={e} value={e}>{e.charAt(0).toUpperCase() + e.slice(1)} Level</option>)}
            </select>
          </div>
        </div>

        <div className="form-section-title" style={{ marginTop: 8 }}>Salary & Details</div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Min Salary ($)</label>
            <input type="number" value={form['salary.min']} onChange={e => set('salary.min', e.target.value)} placeholder="e.g. 60000" />
          </div>
          <div className="form-group">
            <label className="form-label">Max Salary ($)</label>
            <input type="number" value={form['salary.max']} onChange={e => set('salary.max', e.target.value)} placeholder="e.g. 100000" />
          </div>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Salary Period</label>
            <select value={form['salary.period']} onChange={e => set('salary.period', e.target.value)}>
              <option value="hourly">Hourly</option>
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Application Deadline</label>
            <input type="date" value={form.deadline?.slice(0, 10) || ''} onChange={e => set('deadline', e.target.value)} />
          </div>
        </div>

        <div className="form-group" style={{ marginTop: 8 }}>
          <label className="form-label">Skills <span className="form-hint">(comma separated)</span></label>
          <input value={typeof form.skills === 'string' ? form.skills : form.skills?.join(', ')} onChange={e => set('skills', e.target.value)} placeholder="React, Node.js, MongoDB..." />
        </div>

        <div className="form-section-title" style={{ marginTop: 8 }}>Job Content</div>
        <div className="form-group">
          <label className="form-label">Job Description *</label>
          <textarea rows={5} value={form.description} onChange={e => set('description', e.target.value)} required placeholder="Full job description..." />
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Responsibilities <span className="form-hint">(one per line)</span></label>
            <textarea rows={5} value={typeof form.responsibilities === 'string' ? form.responsibilities : form.responsibilities?.join('\n')} onChange={e => set('responsibilities', e.target.value)} placeholder="Lead development team&#10;Write clean code&#10;Code reviews" />
          </div>
          <div className="form-group">
            <label className="form-label">Requirements <span className="form-hint">(one per line)</span></label>
            <textarea rows={5} value={typeof form.requirements === 'string' ? form.requirements : form.requirements?.join('\n')} onChange={e => set('requirements', e.target.value)} placeholder="5+ years experience&#10;Bachelor's degree&#10;Strong communication" />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Benefits <span className="form-hint">(one per line)</span></label>
          <textarea rows={3} value={typeof form.benefits === 'string' ? form.benefits : form.benefits?.join('\n')} onChange={e => set('benefits', e.target.value)} placeholder="Health insurance&#10;Remote work&#10;Annual bonus" />
        </div>

        <div className="toggle-row">
          <label className="toggle-label">
            <input type="checkbox" checked={form.featured} onChange={e => set('featured', e.target.checked)} />
            <span>Featured Job</span>
          </label>
          <label className="toggle-label">
            <input type="checkbox" checked={form.isActive} onChange={e => set('isActive', e.target.checked)} />
            <span>Active / Published</span>
          </label>
        </div>

        <div className="form-actions" style={{ marginTop: 8 }}>
          <Link to="/admin/jobs" className="btn btn-outline">Cancel</Link>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving...' : (existing ? 'Update Job' : 'Post Job')}
          </button>
        </div>
      </form>
    </div>
  );
}

function JobsList() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const res = await jobsAPI.getAll({ page, limit: 15, sort: '-createdAt' });
      setJobs(res.data.jobs);
      setTotal(res.data.total);
    } catch { toast.error('Failed to load jobs'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchJobs(); }, [page]);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this job?')) return;
    try {
      await jobsAPI.delete(id);
      toast.success('Job deleted');
      fetchJobs();
    } catch { toast.error('Failed to delete'); }
  };

  const handleToggle = async (job) => {
    try {
      await jobsAPI.update(job._id, { isActive: !job.isActive });
      toast.success(`Job ${job.isActive ? 'deactivated' : 'activated'}`);
      fetchJobs();
    } catch { toast.error('Failed to update'); }
  };

  return (
    <div className="admin-page fade-in">
      <div className="admin-page-header">
        <div>
          <h1>Manage Jobs</h1>
          <p>{total} total jobs</p>
        </div>
        <Link to="/admin/jobs/new" className="btn btn-primary">+ Post New Job</Link>
      </div>

      <div className="admin-card">
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center' }}><div className="loading-spinner" /></div>
        ) : jobs.length === 0 ? (
          <div className="empty-state"><div style={{ fontSize: '2rem' }}>💼</div><p>No jobs yet</p><Link to="/admin/jobs/new" className="btn btn-primary" style={{ marginTop: 12 }}>Post First Job</Link></div>
        ) : (
          <div className="admin-table-wrap">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Job Title</th><th>Type</th><th>Location</th><th>Applied</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {jobs.map(job => (
                  <tr key={job._id}>
                    <td>
                      <div className="table-job-title">{job.title}</div>
                      <div className="table-job-company">{job.company}</div>
                    </td>
                    <td><span className="badge badge-blue">{job.type}</span></td>
                    <td className="table-muted">{job.location}</td>
                    <td className="table-muted">{job.applicationCount}</td>
                    <td>
                      <span className={`badge ${job.isActive ? 'badge-green' : 'badge-gray'}`}>
                        {job.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div className="table-actions">
                        <Link to={`/admin/jobs/edit/${job._id}`} className="btn btn-outline btn-sm">Edit</Link>
                        <button className="btn btn-outline btn-sm" onClick={() => handleToggle(job)}>
                          {job.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(job._id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function EditJobWrapper() {
  const [job, setJob] = useState(null);
  const jobId = window.location.pathname.split('/').pop();
  useEffect(() => {
    if (jobId && jobId !== 'new') {
      jobsAPI.getById(jobId).then(res => {
        const j = res.data;
        setJob({ ...j, skills: j.skills?.join(', '), requirements: j.requirements?.join('\n'), responsibilities: j.responsibilities?.join('\n'), benefits: j.benefits?.join('\n'), 'salary.min': j.salary?.min || '', 'salary.max': j.salary?.max || '', 'salary.period': j.salary?.period || 'yearly' });
      }).catch(() => toast.error('Failed to load job'));
    }
  }, [jobId]);
  if (!job) return <div className="page-loader"><div className="loading-spinner" /></div>;
  return <JobForm existing={job} />;
}

export default function AdminJobs() {
  return (
    <Routes>
      <Route path="/" element={<JobsList />} />
      <Route path="/new" element={<JobForm />} />
      <Route path="/edit/:id" element={<EditJobWrapper />} />
    </Routes>
  );
}
