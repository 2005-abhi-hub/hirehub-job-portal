import React from 'react';
import { Link } from 'react-router-dom';
import useAdminStats from '../../hooks/useAdminStats';
import { STATUS_CONFIG } from '../../constants';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminOverview() {
  const { stats, loading } = useAdminStats();

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
      <div className="loading-spinner" />
    </div>
  );

  const metaCards = [
    { label: 'Total Users',   value: stats?.totalUsers        || 0, icon: '👥', color: 'blue',   link: '/admin/users' },
    { label: 'Total Jobs',    value: stats?.totalJobs         || 0, icon: '💼', color: 'green',  link: '/admin/jobs' },
    { label: 'Applications',  value: stats?.totalApplications || 0, icon: '📋', color: 'purple', link: '/admin/applications' },
    { label: 'Active Jobs',   value: stats?.activeJobs        || 0, icon: '✅', color: 'amber',  link: '/admin/jobs' },
  ];

  const statusColorMap = { blue: 'var(--accent-g)', green: 'var(--green-bg)', purple: 'var(--purple-bg)', amber: 'var(--amber-bg)' };

  return (
    <div className="admin-page fade-in">
      <div className="admin-page-header">
        <h1>Dashboard Overview</h1>
        <p>Welcome back! Here's what's happening.</p>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        {metaCards.map(card => (
          <Link to={card.link} key={card.label} className={`stat-card stat-${card.color}`}>
            <div className="stat-card-icon" style={{ background: statusColorMap[card.color] }}>{card.icon}</div>
            <div className="stat-card-content">
              <p className="stat-card-value">{card.value.toLocaleString()}</p>
              <p className="stat-card-label">{card.label}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="admin-grid-2">
        {/* Recent Applications */}
        <div className="admin-card">
          <div className="admin-card-header">
            <h3>Recent Applications</h3>
            <Link to="/admin/applications" className="view-all-link">View all →</Link>
          </div>
          <div className="recent-list">
            {!stats?.recentApplications?.length
              ? <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No applications yet</p>
              : stats.recentApplications.map(app => {
                  const cfg = STATUS_CONFIG[app.status] || STATUS_CONFIG.pending;
                  return (
                    <div key={app._id} className="recent-item">
                      <div className="recent-avatar">{app.applicant?.name?.charAt(0)}</div>
                      <div className="recent-info">
                        <p className="recent-name">{app.applicant?.name}</p>
                        <p className="recent-sub">applied for <strong>{app.job?.title}</strong></p>
                      </div>
                      <span className={`badge ${cfg.badgeClass}`}>{app.status}</span>
                    </div>
                  );
                })}
          </div>
        </div>

        {/* Applications by Status */}
        <div className="admin-card">
          <div className="admin-card-header"><h3>Applications by Status</h3></div>
          <div className="status-breakdown">
            {stats?.applicationsByStatus?.map(s => (
              <div key={s._id} className="status-bar-item">
                <div className="status-bar-label">
                  <span className={`badge ${STATUS_CONFIG[s._id]?.badgeClass || 'badge-gray'}`}>{s._id}</span>
                  <span className="status-count">{s.count}</span>
                </div>
                <div className="status-bar-track">
                  <div className="status-bar-fill"
                    style={{ width: `${(s.count / (stats?.totalApplications || 1)) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Jobs by Category */}
        <div className="admin-card">
          <div className="admin-card-header">
            <h3>Jobs by Category</h3>
            <Link to="/admin/jobs" className="view-all-link">Manage →</Link>
          </div>
          <div className="category-breakdown">
            {stats?.jobsByCategory?.slice(0, 6).map(c => (
              <div key={c._id} className="category-row">
                <span className="cat-name">{c._id}</span>
                <div className="cat-bar">
                  <div className="cat-fill" style={{ width: `${(c.count / (stats?.totalJobs || 1)) * 100}%` }} />
                </div>
                <span className="cat-count">{c.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="admin-card">
          <div className="admin-card-header"><h3>Quick Actions</h3></div>
          <div className="quick-actions-grid">
            {[
              ['➕', 'Post New Job',       '/admin/jobs/new'],
              ['📋', 'Review Apps',        '/admin/applications'],
              ['👥', 'Manage Users',       '/admin/users'],
              ['🌐', 'View Job Board',     '/jobs'],
            ].map(([icon, label, link]) => (
              <Link key={label} to={link} className="quick-action-btn">
                <span>{icon}</span><span>{label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
