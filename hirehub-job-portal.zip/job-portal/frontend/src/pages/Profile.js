import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import authService from '../services/authService';
import toast from 'react-hot-toast';
import './Profile.css';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [tab,    setTab]    = useState('profile');
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    name:      user?.name      || '',
    bio:       user?.bio       || '',
    phone:     user?.phone     || '',
    location:  user?.location  || '',
    skills:    user?.skills?.join(', ') || '',
    linkedIn:  user?.linkedIn  || '',
    portfolio: user?.portfolio || '',
    resume:    user?.resume    || '',
  });

  const [pwForm, setPwForm] = useState({
    currentPassword:  '',
    newPassword:      '',
    confirmPassword:  '',
  });

  const set    = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));
  const setPw  = (k) => (e) => setPwForm(f => ({ ...f, [k]: e.target.value }));

  const handleProfileSave = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Name is required'); return; }
    setSaving(true);
    try {
      const res = await authService.updateProfile({
        ...form,
        skills: form.skills.split(',').map(s => s.trim()).filter(Boolean),
      });
      updateUser(res.data);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    const { currentPassword, newPassword, confirmPassword } = pwForm;
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('Please fill in all fields'); return;
    }
    if (newPassword !== confirmPassword) { toast.error('Passwords do not match'); return; }
    if (newPassword.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    setSaving(true);
    try {
      await authService.changePassword({ currentPassword, newPassword });
      toast.success('Password updated!');
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update password');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="profile-page fade-in">
      <div className="container">
        <div className="profile-layout">
          {/* ── Sidebar ── */}
          <aside className="profile-sidebar">
            <div className="profile-avatar-card">
              <div className="profile-avatar-big">{user?.name?.charAt(0)?.toUpperCase()}</div>
              <h2 className="profile-name">{user?.name}</h2>
              <p className="profile-email">{user?.email}</p>
              <span className={`badge ${user?.role === 'admin' ? 'badge-amber' : 'badge-blue'}`}>
                {user?.role}
              </span>
            </div>
            <nav className="profile-nav">
              {[['profile','👤 Profile Info'],['security','🔒 Security']].map(([t, label]) => (
                <button key={t}
                  className={`profile-nav-btn ${tab === t ? 'active' : ''}`}
                  onClick={() => setTab(t)}>
                  {label}
                </button>
              ))}
            </nav>
          </aside>

          {/* ── Main ── */}
          <main className="profile-main">
            {tab === 'profile' && (
              <div className="card fade-in">
                <h2 className="section-title">Personal Information</h2>
                <form onSubmit={handleProfileSave} className="profile-form">
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">Full Name</label>
                      <input value={form.name} onChange={set('name')} required />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Phone Number</label>
                      <input value={form.phone} onChange={set('phone')} placeholder="+1 234 567 8900" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Bio</label>
                    <textarea rows={3} value={form.bio} onChange={set('bio')}
                      placeholder="Tell employers about yourself..." />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Location</label>
                    <input value={form.location} onChange={set('location')} placeholder="City, Country" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">
                      Skills <span className="form-hint">(comma separated)</span>
                    </label>
                    <input value={form.skills} onChange={set('skills')} placeholder="React, Node.js, Python..." />
                  </div>
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">LinkedIn URL</label>
                      <input value={form.linkedIn} onChange={set('linkedIn')} placeholder="https://linkedin.com/in/..." />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Portfolio URL</label>
                      <input value={form.portfolio} onChange={set('portfolio')} placeholder="https://yoursite.com" />
                    </div>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Resume / Google Drive URL</label>
                    <input value={form.resume} onChange={set('resume')} placeholder="https://drive.google.com/..." />
                  </div>
                  <div className="form-actions">
                    <button type="submit" className="btn btn-primary" disabled={saving}>
                      {saving ? 'Saving...' : 'Save Changes'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {tab === 'security' && (
              <div className="card fade-in">
                <h2 className="section-title">Change Password</h2>
                <form onSubmit={handlePasswordChange} className="profile-form">
                  <div className="form-group">
                    <label className="form-label">Current Password</label>
                    <input type="password" value={pwForm.currentPassword} onChange={setPw('currentPassword')} />
                  </div>
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">New Password</label>
                      <input type="password" value={pwForm.newPassword} onChange={setPw('newPassword')}
                        placeholder="Min 6 characters" />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Confirm New Password</label>
                      <input type="password" value={pwForm.confirmPassword} onChange={setPw('confirmPassword')} />
                    </div>
                  </div>
                  <div className="form-actions">
                    <button type="submit" className="btn btn-primary" disabled={saving}>
                      {saving ? 'Updating...' : 'Update Password'}
                    </button>
                  </div>
                </form>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
