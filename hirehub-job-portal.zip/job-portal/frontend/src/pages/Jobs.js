import React, { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import useJobs from '../hooks/useJobs';
import useSavedJobs from '../hooks/useSavedJobs';
import JobCard from '../components/JobCard';
import { CATEGORIES, JOB_TYPES, EXPERIENCE_LEVELS, EXPERIENCE_LABELS } from '../constants';
import './Jobs.css';

export default function Jobs() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { isSaved, toggleSave } = useSavedJobs();

  const { jobs, total, pages, loading, filters, updateFilter, resetFilters } = useJobs({
    search:     searchParams.get('search')   || '',
    category:   searchParams.get('category') || 'All',
    type:       'All',
    location:   searchParams.get('location') || '',
    experience: 'All',
    page:       1,
  });

  // Keep URL in sync with search/location filters
  useEffect(() => {
    const p = new URLSearchParams(searchParams);
    filters.search   ? p.set('search',   filters.search)   : p.delete('search');
    filters.location ? p.set('location', filters.location) : p.delete('location');
    filters.category && filters.category !== 'All'
      ? p.set('category', filters.category) : p.delete('category');
    setSearchParams(p, { replace: true });
  }, [filters.search, filters.location, filters.category]); // eslint-disable-line

  return (
    <div className="jobs-page fade-in">
      <div className="jobs-hero">
        <div className="container">
          <h1>Browse <span className="gradient-text">{total}</span> Open Positions</h1>
          <div className="jobs-search-bar">
            <input
              placeholder="🔍  Search jobs, skills, companies..."
              value={filters.search}
              onChange={e => updateFilter('search', e.target.value)}
            />
            <input
              placeholder="📍  Location..."
              value={filters.location}
              onChange={e => updateFilter('location', e.target.value)}
              className="location-input"
            />
          </div>
        </div>
      </div>

      <div className="container jobs-layout">
        {/* ── Sidebar Filters ── */}
        <aside className="filters-panel">
          <h3 className="filter-title">Filters</h3>

          <div className="filter-group">
            <label>Category</label>
            <select value={filters.category} onChange={e => updateFilter('category', e.target.value)}>
              <option value="All">All Categories</option>
              {CATEGORIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>

          <div className="filter-group">
            <label>Job Type</label>
            {['All', ...JOB_TYPES].map(t => (
              <label key={t} className={`radio-option ${filters.type === t ? 'selected' : ''}`}>
                <input type="radio" name="type" value={t} checked={filters.type === t}
                  onChange={() => updateFilter('type', t)} />
                <span>{t === 'All' ? 'All Types' : t.charAt(0).toUpperCase() + t.slice(1)}</span>
              </label>
            ))}
          </div>

          <div className="filter-group">
            <label>Experience Level</label>
            {['All', ...EXPERIENCE_LEVELS].map(e => (
              <label key={e} className={`radio-option ${filters.experience === e ? 'selected' : ''}`}>
                <input type="radio" name="experience" value={e} checked={filters.experience === e}
                  onChange={() => updateFilter('experience', e)} />
                <span>{e === 'All' ? 'All Levels' : EXPERIENCE_LABELS[e]}</span>
              </label>
            ))}
          </div>

          <button className="btn btn-outline btn-sm" style={{ width: '100%', marginTop: 8 }}
            onClick={resetFilters}>
            Clear All Filters
          </button>
        </aside>

        {/* ── Job List ── */}
        <main className="jobs-main">
          <div className="jobs-toolbar">
            <p className="results-count">{total} jobs found</p>
            <select onChange={e => updateFilter('sort', e.target.value)} defaultValue="-createdAt">
              <option value="-createdAt">Newest First</option>
              <option value="-applicationCount">Most Applied</option>
              <option value="-views">Most Viewed</option>
            </select>
          </div>

          {loading ? (
            <div className="jobs-loading">
              {[...Array(6)].map((_, i) => <div key={i} className="job-skeleton" />)}
            </div>
          ) : jobs.length === 0 ? (
            <div className="empty-state">
              <div style={{ fontSize: '3rem' }}>🔍</div>
              <h3>No jobs found</h3>
              <p>Try adjusting your filters or search terms</p>
            </div>
          ) : (
            <div className="jobs-list">
              {jobs.map(job => (
                <JobCard key={job._id} job={job} saved={isSaved(job._id)} onSave={toggleSave} />
              ))}
            </div>
          )}

          {pages > 1 && (
            <div className="pagination">
              <button className="btn btn-outline btn-sm" disabled={filters.page === 1}
                onClick={() => updateFilter('page', filters.page - 1)}>← Prev</button>
              {[...Array(pages)].map((_, i) => (
                <button key={i}
                  className={`btn btn-sm ${filters.page === i + 1 ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => updateFilter('page', i + 1)}>{i + 1}</button>
              ))}
              <button className="btn btn-outline btn-sm" disabled={filters.page === pages}
                onClick={() => updateFilter('page', filters.page + 1)}>Next →</button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
