import React from 'react';
import { Link } from 'react-router-dom';
import './JobCard.css';

const typeColors = {
  'full-time': 'badge-green',
  'part-time': 'badge-blue',
  'contract': 'badge-amber',
  'internship': 'badge-purple',
  'remote': 'badge-green',
};

const expLabels = { entry: 'Entry Level', mid: 'Mid Level', senior: 'Senior', lead: 'Lead', executive: 'Executive' };

export default function JobCard({ job, saved, onSave }) {
  const formatSalary = (salary) => {
    if (!salary?.min && !salary?.max) return null;
    const fmt = (n) => n >= 1000 ? `${(n/1000).toFixed(0)}k` : n;
    if (salary.min && salary.max) return `$${fmt(salary.min)} – $${fmt(salary.max)}`;
    if (salary.min) return `From $${fmt(salary.min)}`;
    return `Up to $${fmt(salary.max)}`;
  };

  const timeAgo = (date) => {
    const diff = Date.now() - new Date(date);
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days}d ago`;
    if (days < 30) return `${Math.floor(days/7)}w ago`;
    return `${Math.floor(days/30)}mo ago`;
  };

  const salary = formatSalary(job.salary);

  return (
    <div className={`job-card fade-in ${job.featured ? 'featured' : ''}`}>
      {job.featured && <span className="featured-badge">⭐ Featured</span>}
      <div className="job-card-header">
        <div className="company-avatar">
          {job.companyLogo ? (
            <img src={job.companyLogo} alt={job.company} />
          ) : (
            <span>{job.company?.charAt(0)}</span>
          )}
        </div>
        <div className="job-meta">
          <h3 className="job-title">
            <Link to={`/jobs/${job._id}`}>{job.title}</Link>
          </h3>
          <p className="job-company">{job.company}</p>
        </div>
        {onSave && (
          <button className={`save-btn ${saved ? 'saved' : ''}`} onClick={() => onSave(job._id)} title={saved ? 'Unsave' : 'Save'}>
            {saved ? '♥' : '♡'}
          </button>
        )}
      </div>

      <div className="job-tags">
        <span className={`badge ${typeColors[job.type] || 'badge-gray'}`}>{job.type}</span>
        <span className="badge badge-gray">📍 {job.location}</span>
        {job.experienceLevel && <span className="badge badge-gray">{expLabels[job.experienceLevel]}</span>}
        <span className="badge badge-gray">{job.category}</span>
      </div>

      {job.skills?.length > 0 && (
        <div className="job-skills">
          {job.skills.slice(0, 4).map(s => <span key={s} className="skill-tag">{s}</span>)}
          {job.skills.length > 4 && <span className="skill-tag muted">+{job.skills.length - 4}</span>}
        </div>
      )}

      <div className="job-card-footer">
        <div className="job-info-row">
          {salary && <span className="salary">💰 {salary} / {job.salary?.period || 'year'}</span>}
          <span className="posted-time">{timeAgo(job.createdAt)}</span>
        </div>
        <div className="job-actions">
          <span className="applicants-count">{job.applicationCount || 0} applied</span>
          <Link to={`/jobs/${job._id}`} className="btn btn-primary btn-sm">View Job →</Link>
        </div>
      </div>
    </div>
  );
}
