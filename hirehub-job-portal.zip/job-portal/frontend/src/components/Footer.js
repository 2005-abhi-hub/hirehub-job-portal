import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="footer-brand">
          <Link to="/" className="footer-logo"><span className="logo-icon">⬡</span> HireHub</Link>
          <p>Connecting talent with opportunity. Find your dream career today.</p>
        </div>
        <div className="footer-links">
          <div className="footer-col">
            <h4>For Job Seekers</h4>
            <Link to="/jobs">Browse Jobs</Link>
            <Link to="/register">Create Account</Link>
            <Link to="/my-applications">My Applications</Link>
          </div>
          <div className="footer-col">
            <h4>Company</h4>
            <span>About Us</span>
            <span>Contact</span>
            <span>Privacy Policy</span>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} HireHub. Built with React & Node.js.</p>
      </div>
    </footer>
  );
}
