import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/'); };
  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <div className="container nav-inner">
        <Link to="/" className="nav-logo">
          <span className="logo-icon">⬡</span>
          <span>HireHub</span>
        </Link>

        <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
          <Link to="/jobs" className={`nav-link ${isActive('/jobs') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>Browse Jobs</Link>
          {user && !isAdmin && (
            <Link to="/my-applications" className={`nav-link ${isActive('/my-applications') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>My Applications</Link>
          )}
          {isAdmin && (
            <Link to="/admin" className={`nav-link ${location.pathname.startsWith('/admin') ? 'active' : ''}`} onClick={() => setMenuOpen(false)}>Dashboard</Link>
          )}
        </div>

        <div className="nav-actions">
          {user ? (
            <div className="user-menu">
              <Link to={isAdmin ? '/admin' : '/profile'} className="user-avatar">
                <span>{user.name?.charAt(0).toUpperCase()}</span>
              </Link>
              <div className="user-dropdown">
                <div className="dropdown-header">
                  <p className="dropdown-name">{user.name}</p>
                  <p className="dropdown-role">{user.role}</p>
                </div>
                <div className="dropdown-divider" />
                {!isAdmin && <Link to="/profile" className="dropdown-item">Profile</Link>}
                {!isAdmin && <Link to="/my-applications" className="dropdown-item">My Applications</Link>}
                {isAdmin && <Link to="/admin" className="dropdown-item">Admin Dashboard</Link>}
                <div className="dropdown-divider" />
                <button onClick={handleLogout} className="dropdown-item dropdown-logout">Sign Out</button>
              </div>
            </div>
          ) : (
            <div className="auth-buttons">
              <Link to="/login" className="btn btn-outline btn-sm">Sign In</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Get Started</Link>
            </div>
          )}
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
            <span /><span /><span />
          </button>
        </div>
      </div>
    </nav>
  );
}
