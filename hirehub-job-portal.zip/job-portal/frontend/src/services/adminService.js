import API from '../utils/api';

const adminService = {
  getStats:    ()         => API.get('/admin/stats'),
  getUsers:    (params)   => API.get('/admin/users', { params }),
  toggleUser:  (id)       => API.put(`/admin/users/${id}/toggle`),
  updateRole:  (id, role) => API.put(`/admin/users/${id}/role`, { role }),
  deleteUser:  (id)       => API.delete(`/admin/users/${id}`),
};

export default adminService;
