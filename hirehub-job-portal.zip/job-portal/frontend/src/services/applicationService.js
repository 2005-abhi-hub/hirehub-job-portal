import API from '../utils/api';

const applicationService = {
  apply:         (data)   => API.post('/applications', data),
  getMy:         ()       => API.get('/applications/my'),
  check:         (jobId)  => API.get(`/applications/check/${jobId}`),
  withdraw:      (id)     => API.put(`/applications/${id}/withdraw`),
  getAll:        (params) => API.get('/applications', { params }),
  updateStatus:  (id, d)  => API.put(`/applications/${id}/status`, d),
};

export default applicationService;
