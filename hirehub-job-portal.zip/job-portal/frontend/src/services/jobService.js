import API from '../utils/api';

const jobService = {
  getAll:     (params) => API.get('/jobs', { params }),
  getFeatured: ()      => API.get('/jobs/featured'),
  getById:    (id)     => API.get(`/jobs/${id}`),
  create:     (data)   => API.post('/jobs', data),
  update:     (id, d)  => API.put(`/jobs/${id}`, d),
  remove:     (id)     => API.delete(`/jobs/${id}`),
};

export default jobService;
