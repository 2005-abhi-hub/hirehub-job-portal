import API from '../utils/api';

const authService = {
  register:       (data)  => API.post('/auth/register', data),
  login:          (data)  => API.post('/auth/login', data),
  getMe:          ()      => API.get('/auth/me'),
  updateProfile:  (data)  => API.put('/auth/profile', data),
  changePassword: (data)  => API.put('/auth/change-password', data),
  saveJob:        (jobId) => API.post(`/auth/save-job/${jobId}`),
};

export default authService;
