# ⬡ HireHub — Full-Stack Job Portal

A complete, production-ready job portal built with **React**, **Node.js**, **Express**, and **MongoDB**.

---

## 📁 Folder Structure

```
hirehub/
│
├── package.json                  ← root: runs both frontend + backend together
├── .gitignore
├── README.md
│
├── backend/                      ← Node.js + Express REST API
│   ├── server.js                 ← entry point, middleware, routes, error handler
│   ├── seed.js                   ← seeds DB with demo users & jobs
│   ├── package.json
│   ├── .env.example
│   ├── .gitignore
│   │
│   ├── config/
│   │   ├── db.js                 ← MongoDB connection (Mongoose)
│   │   └── jwt.js                ← generateToken / verifyToken helpers
│   │
│   ├── models/
│   │   ├── User.js               ← User schema (bcrypt hashing, role)
│   │   ├── Job.js                ← Job schema (text index, salary, skills)
│   │   └── Application.js        ← Application schema (job + applicant ref)
│   │
│   ├── controllers/
│   │   ├── authController.js     ← register, login, profile, password, savedJobs
│   │   ├── jobController.js      ← CRUD jobs + featured + view counter
│   │   ├── applicationController.js ← apply, my apps, check, withdraw, admin review
│   │   └── adminController.js    ← stats, user management
│   │
│   ├── routes/
│   │   ├── auth.js               ← POST /register  POST /login  GET /me ...
│   │   ├── jobs.js               ← GET /  GET /featured  GET /:id  POST PUT DELETE
│   │   ├── applications.js       ← POST /  GET /my  GET /check  PUT /status ...
│   │   └── admin.js              ← GET /stats  GET /users  PUT toggle/role  DELETE
│   │
│   ├── middleware/
│   │   └── auth.js               ← protect (JWT verify)  adminOnly (role check)
│   │
│   └── utils/
│       ├── asyncHandler.js       ← wraps async controllers, forwards errors
│       ├── apiError.js           ← custom ApiError class with statusCode
│       └── apiResponse.js        ← sendResponse() standard JSON helper
│
└── frontend/                     ← React 18 SPA
    ├── package.json
    ├── .env.example
    ├── .gitignore
    │
    ├── public/
    │   └── index.html
    │
    └── src/
        ├── index.js              ← ReactDOM.createRoot entry
        ├── index.css             ← global design system (CSS vars, utilities)
        ├── App.js                ← BrowserRouter + all routes + Toaster
        │
        ├── constants/
        │   └── index.js          ← CATEGORIES, JOB_TYPES, STATUS_CONFIG, etc.
        │
        ├── context/
        │   └── AuthContext.js    ← global auth state (user, login, logout, updateUser)
        │
        ├── services/             ← thin wrappers around Axios API calls
        │   ├── authService.js
        │   ├── jobService.js
        │   ├── applicationService.js
        │   ├── adminService.js
        │   └── index.js          ← barrel export
        │
        ├── hooks/                ← reusable React hooks
        │   ├── useJobs.js        ← fetches + filters jobs with state
        │   ├── useDebounce.js    ← debounces a value (search inputs)
        │   ├── useLocalStorage.js← useState that persists to localStorage
        │   └── index.js          ← barrel export
        │
        ├── utils/
        │   └── api.js            ← Axios instance + interceptors + legacy exports
        │
        ├── components/           ← reusable UI components
        │   ├── Navbar.js / .css
        │   ├── Footer.js / .css
        │   ├── JobCard.js / .css
        │   └── ProtectedRoute.js
        │
        └── pages/                ← route-level page components
            ├── Home.js / .css
            ├── Jobs.js / .css
            ├── JobDetail.js / .css
            ├── Auth.js / .css    ← Login + Register
            ├── MyApplications.js / .css
            ├── Profile.js / .css
            ├── AdminDashboard.js / .css
            └── admin/            ← admin sub-pages (loaded inside AdminDashboard)
                ├── AdminOverview.js
                ├── AdminJobs.js
                ├── AdminApplications.js
                ├── AdminUsers.js
                └── AdminPages.css
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v18+
- **MongoDB** (local) — or a free [MongoDB Atlas](https://cloud.mongodb.com/) cluster

### 1 — Install all dependencies

```bash
# From the project root
npm run install:all
```

### 2 — Configure the backend

```bash
cd backend
cp .env.example .env
```

Edit `.env`:

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/hirehub
JWT_SECRET=replace_this_with_a_long_random_string
JWT_EXPIRES_IN=7d
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

### 3 — Seed sample data (optional but recommended)

```bash
npm run seed          # from project root
# or
cd backend && node seed.js
```

### 4 — Run in development (both servers at once)

```bash
# From project root — starts backend :5000 and frontend :3000 concurrently
npm run dev
```

Or start them separately:

```bash
npm run dev:backend   # backend only
npm run dev:frontend  # frontend only
```

---

## 🔑 Demo Credentials (after seeding)

| Role       | Email                 | Password     |
|------------|-----------------------|--------------|
| Admin      | admin@hirehub.com     | admin123     |
| Job Seeker | alice@example.com     | password123  |
| Job Seeker | bob@example.com       | password123  |

---

## 🛠️ API Reference

### Auth  `/api/auth`
| Method | Endpoint              | Auth | Description          |
|--------|-----------------------|------|----------------------|
| POST   | `/register`           | —    | Register             |
| POST   | `/login`              | —    | Login                |
| GET    | `/me`                 | JWT  | Get current user     |
| PUT    | `/profile`            | JWT  | Update profile       |
| PUT    | `/change-password`    | JWT  | Change password      |
| POST   | `/save-job/:jobId`    | JWT  | Toggle saved job     |

### Jobs  `/api/jobs`
| Method | Endpoint     | Auth       | Description               |
|--------|--------------|------------|---------------------------|
| GET    | `/`          | —          | List jobs (with filters)  |
| GET    | `/featured`  | —          | Featured jobs             |
| GET    | `/:id`       | —          | Single job                |
| POST   | `/`          | Admin      | Create job                |
| PUT    | `/:id`       | Admin      | Update job                |
| DELETE | `/:id`       | Admin      | Delete job                |

### Applications  `/api/applications`
| Method | Endpoint           | Auth       | Description           |
|--------|--------------------|------------|-----------------------|
| POST   | `/`                | JWT        | Apply for a job       |
| GET    | `/my`              | JWT        | My applications       |
| GET    | `/check/:jobId`    | JWT        | Check if applied      |
| PUT    | `/:id/withdraw`    | JWT        | Withdraw              |
| GET    | `/`                | Admin      | All applications      |
| PUT    | `/:id/status`      | Admin      | Update status         |

### Admin  `/api/admin`
| Method | Endpoint                | Auth  | Description         |
|--------|-------------------------|-------|---------------------|
| GET    | `/stats`                | Admin | Dashboard stats     |
| GET    | `/users`                | Admin | List users          |
| PUT    | `/users/:id/toggle`     | Admin | Toggle active       |
| PUT    | `/users/:id/role`       | Admin | Change role         |
| DELETE | `/users/:id`            | Admin | Delete user         |

---

## 🎨 Tech Stack

| Layer      | Technology                                       |
|------------|--------------------------------------------------|
| Frontend   | React 18, React Router v6, Axios, react-hot-toast |
| Styling    | Custom CSS, Syne + DM Sans fonts, CSS variables  |
| Backend    | Node.js, Express.js                              |
| Database   | MongoDB + Mongoose                               |
| Auth       | JWT (jsonwebtoken) + bcryptjs (12 salt rounds)   |
| Validation | express-validator                                |

---

## 🔐 Security Notes

- Passwords hashed with bcryptjs (12 salt rounds)
- JWT tokens expire in 7 days (configurable via `JWT_EXPIRES_IN`)
- All protected routes guarded by `protect` middleware
- Admin-only endpoints additionally guarded by `adminOnly` middleware
- `password` field excluded from all queries by default (`select: false`)
- Input validation on all write endpoints via express-validator
